# Emmy Noether — Matematične děla po medžuslovjansky

Statje 1–43, lekcije 1929/30 v zapisu M. Deuringa, dělo Kapferera i Noether s dopolnjenjem, bibliografija i končne spisky.

Ohranite strukturu arhiva. Vsaky glavny fajl kompilujte dva razy s XeLaTeX iz jego direktorija. Pakety i fonty sut ukazane v preambuli.

- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_latin/base-papers1-43-isv.tex`
- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_latin/44-book-isv.tex`
- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_latin/45-isv.tex`
- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_latin/bib-isv.tex`

[Avtorstvo i prava](RIGHTS.md).
