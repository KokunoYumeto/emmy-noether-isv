# Emmy Noether — Математичне дєла по меджусловјанскы

Статје 1–43, лекције 1929/30 в запису M. Deuringa, дєло Kapferera и Noether с дополнјењем, библиографија и конечне спискы.

Охраните структуру архива. Всаки главны фајл компилујте два разы с XeLaTeX из јего директорија. Пакеты и фонты сут указане в преамбули.

- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_cyrillic/base-papers1-43-isv-cyrl.tex`
- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_cyrillic/44-book-isv-cyrl.tex`
- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_cyrillic/45-isv-cyrl.tex`
- `NOETHER_INTERSLAVIC_EDITABLE_SOURCES/source_cyrillic/bib-isv-cyrl.tex`

[Авторство и права](RIGHTS.md).
