# Emmy Noether — Matematične děla po medžuslovjansky

Statje 1–43, lekcije 1929/30 v zapisu M. Deuringa, dělo Kapferera i Noether s dopolnjenjem, bibliografija i končne spisky.

Prěmy kumulativny fajl LaTeX sodrživa vse teksty i preambuly v redaktovateljnoj formě. Program Python izvlačuje iztočne fajly, kompiluje jih s XeLaTeX i sjedinjaje PDF česti v porědku čitanja. Obrazy i stranice PDF ne zaměnjajut transkripciju. ZIP ohranjaje iztočnu strukturu, tuty že kumulativny LaTeX i program. Potrěbni sut Python 3, pypdf, pakety TeX i fonty ukazane v preambulah. Bajty PDF mogut zavisěti od versij TeX i fontov. Fiksovana vnutrišnja data tipografije ne jest data publikacije.

```text
python -m pip install pypdf
python build.py 05-noether-isv-Latn-emendations.tex --output 04-noether-isv-Latn-emendations.pdf
```

Program stvorjeny AI: OpenAI Codex — GPT-6 Astra, Ultra, 24 oktobra 2026.

Prěklad stvorjeny AI. Popravky i tipografija: OpenAI Codex — GPT-6 Astra, usilje Ultra. Avtorstvo Emmy Noether, M. Deuringa i nazvanyh soavtorov ostavaje ohranjeno. Izdatelju ne pripisyvaje se člověčsky prěklad ili nezavisna člověčska naučna recenzija.

Točny model i usilje za naslědovany prěklad ne sut ustanovjene iz ohranjenyh zapisov. Popravky i tipografija stvorjene AI: 23–24 oktobra 2026. Izdanje: 24 oktobra 2026.
