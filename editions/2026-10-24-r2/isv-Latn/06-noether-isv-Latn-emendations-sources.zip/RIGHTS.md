# Avtorstvo i prava

Prěklad stvorjeny AI. Popravky i tipografija: OpenAI Codex — GPT-6 Astra, usilje Ultra. Avtorstvo Emmy Noether, M. Deuringa i nazvanyh soavtorov ostavaje ohranjeno. Izdatelju ne pripisyvaje se člověčsky prěklad ili nezavisna člověčska naučna recenzija.

Točny model i usilje za naslědovany prěklad ne sut ustanovjene iz ohranjenyh zapisov. Popravky i tipografija stvorjene AI: 23–24 oktobra 2026; Claude Opus 5.5 (Anthropic), 26 oktobra 2026, vključajuči formuly srovnane s německym tekstom, čitanym iz pečatnyh stranic Noether. Izdanje: 26 oktobra 2026.

Děla Emmy Noether sut v javnom dobru. V toj měrě, v kakoj izdatelj imaje prava na prěklad, popravky i tipografiju stvorjene AI, on jih daruje v javno dobro po [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). Lekcije zapisane M. Deuringom, rabota H. Kapferera i prinos nazvanyh soavtorov ohranjajut svoj pravny status.

[Protivjenja nositeljev prav](https://github.com/KokunoYumeto/emmy-noether-isv/issues/new).
