# Avtorstvo i prava

Prěklad stvorjeny AI. Popravky i tipografija: OpenAI Codex — GPT-6 Astra, usilje Ultra. Avtorstvo Emmy Noether, M. Deuringa i nazvanyh soavtorov ostavaje ohranjeno. Izdatelju ne pripisyvaje se člověčsky prěklad ili nezavisna člověčska naučna recenzija.

Točny model i usilje za naslědovany prěklad ne sut ustanovjene iz ohranjenyh zapisov. Popravky i tipografija stvorjene AI: 23–24 oktobra 2026; Claude Opus 5.5 (Anthropic), 26–27 oktobra 2026, vključajuči formuly srovnane s německym tekstom, čitanym iz pečatnyh stranic Noether. Izdanje: 27 oktobra 2026.

Emmy Noether umrěla v 1935 godu, zato jej děla sut v obćem dobru v Evropejskom Sojuzu i vsěde, kde srok ohrany konči 70 lět po smrti avtora. V Sjedinjenyh Državah jej statje prvo objavjene v 1931 godu ili pozdněje ostajut ohranjene do 95 lět po objavjenju (statje iz 1931 goda budut slobodne od 1. januara 2027). V měrě, v kakoj izdavatelj imaje prava na prevod, popravky i sazbu izdělane UI, on jih predavaje v obćo dobro po [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). Lekcije v zapisu M. Deuringa, dělo H. Kapferera i vklady nazvanyh soavtorov ne sut obuhvačene tutoju izjavoju; prava na nih ostajut u jih avtorov ili naslědnikov.

[Protivjenja nositeljev prav](https://github.com/KokunoYumeto/emmy-noether-isv/issues/new).
