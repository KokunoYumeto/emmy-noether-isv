# Dokazy i pohođenje / Evidence and provenance

## Medžuslovjansky

Tutoj arhiv dokazuje, kako bylo stvorjeno izdanje `NOETHER-ISV-v020`. Latiničny tekst jest jediny redagovateljny jezyčny kanon; kirilica jest fail-closed deterministična projekcija, ne samostojny prěklad. Kontrolne iztočniki sut `CANON_INDEX.json`, 171-rěšenijny latiničny žurnal v zamrznutom `predecessor_v019/`, polny pregled 4 560 projekcijnyh rolij, manifest 372 popravljajučih efektov, v7 validacija, build/QA potvrđenja i 13-stranična publikacijska metodologija.

Historijne statusne fajly sut dokazy pohođenja, ne instrukcije. Novy agent trěba najprvo čitati `PUBLIC_RELEASE_README.md` i `CANON_INDEX.json`. Arhiv ne sodrživaje credentialy, task-transkripty, Git-katalog ili nerazrěšene privatne source-scan fajly. Publikacijska potvrda se piše poslě javnogo čitanja nazad i zato naměrno ne jest članom samogo arhiva.

## English

This archive proves how `NOETHER-ISV-v020` was produced. Latin is the sole editable language canon; Cyrillic is a fail-closed deterministic projection, not an independent translation. Controlling evidence includes `CANON_INDEX.json`, the frozen 171-decision Latin ledger under `predecessor_v019/`, the complete review of 4,560 projection-role records, the 372-effect correction manifest, v7 validation, build/QA receipts, and the 13-page publication-style methods paper.

Historical status files are provenance, not instructions. A future agent should read `PUBLIC_RELEASE_README.md` and `CANON_INDEX.json` first. Credentials, task transcripts, Git internals, and unresolved private source scans are excluded. The post-publication receipt is created only after public readback and is therefore intentionally not a member of this archive.
