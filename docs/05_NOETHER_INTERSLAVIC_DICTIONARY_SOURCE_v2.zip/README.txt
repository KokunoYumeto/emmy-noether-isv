MATEMATIČNY MEDŽUSLOVJANSKY / MATHEMATICAL INTERSLAVIC
Slovnik i metoda izbora v prěvodu děl Emmy Noether
A dictionary and account of linguistic choices in the translation of Emmy Noether

Medžuslovjansky

Tuta kniga objasnjaje dokumentovane jezyčne izbory v AI-prěvodu matematičnogo
korpusa Emmy Noether. Ona ne zaměnjaje glavno izdanje matematičnyh děl.
Uvod dava metodu; polny slovnik dava 2016 iztočno-medžuslovjanskyh parov,
168 pozdnějših jezyčnyh i redakcijnyh izborov i 12 gramatičnyh ili
pravopisnyh konvencij. Alfabetičny indeks vodi k zapisam. Historijna forma,
zasvědočena upotrěba i opravdana rekomendacija sut jasno razdělene.
Čislene ocěny uvěrjenosti ne sut kalibrovane pravdopodobnosti.

Čitajte PDF; za redagovanje upotrěbite neposrědnji polny LaTeX.
source/main.tex jest modulna verzija togo samogo dokumenta. Živy slovnik
dictionary/index.html omogožnjaje iskanje s polnymi medžuslovjanskymi
i anglijskymi objasnjeniami. JSON i CSV prilogi davajut polne sravnjenja,
točne lokatory i izvorne čislene vagi, kde takie vagi sut zachovane.

Sestavjenje: iz direktorije source pustite slědujuči prikaz tri razy:
    xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
Polny 04_NOETHER_INTERSLAVIC_DICTIONARY.tex možno sestaviti istim načinom
bez vključenyh TeX-fajlov. Potrěbny jest XeLaTeX s paketami navedenymi v
prěambulě. Prednostni font jest Libertinus; alternativy sut TeX Gyre Pagella
ili Times New Roman, Arial i DejaVu Sans Mono ili Consolas. Različne verzije
fontov i TeX-paketov mogut změniti razděl stran. Originalny proverjeny PDF
jest konkretny tipografski rezultat; vyše navedene izvory zachovujut tekst.

Za lokalny HTML upotrěbite obyčny HTTP-server, napriměr iz direktorije paketa:
    python -m http.server 8767 --bind 127.0.0.1
Potom otvorite http://127.0.0.1:8767/dictionary/. Iztočnik slovnika jest
entries.json; app.js prikazuje jego zapisy i tablice. Ne trěbuje se druga
usluga ili jezyčny model. MathJax 3.2.2 jest priloženy s vlastnoju licencijeju.

English

This book explains documented linguistic choices in the AI translation of
the Emmy Noether mathematical corpus. It complements, rather than replaces,
the edition of the mathematical works. The introduction explains the method;
the complete dictionary contains 2,016 source–Interslavic pairs, 168 later
linguistic/editorial choices, and twelve grammatical/orthographic conventions.
An alphabetical index locates entries. Historical proposals, attested usage,
and justified recommendations are distinguished. Numerical confidence
estimates are editorial judgments, not calibrated probabilities.

Read the PDF; use the direct complete LaTeX for editing. source/main.tex is
the modular form of the same document. dictionary/index.html is a searchable
reader with complete Interslavic and English explanations. JSON and CSV
supplements preserve comparisons, precise locators, and actual recorded
numerical weights where these exist.

Build from the source directory with the XeLaTeX command above, three times.
The direct 04_NOETHER_INTERSLAVIC_DICTIONARY.tex also builds independently
of the component TeX files. Required packages are listed in its preamble.
Font choices are described above. Different font/TeX versions may change
pagination; the supplied PDF is the particular inspected typesetting.
For the local HTML reader, run the HTTP-server command above and open the
given loopback URL. No model or remote service is needed to search entries.

The complete HTML book is generated with Pandoc from the same direct LaTeX:
    pandoc --from=latex --to=html5 --standalone --toc \
      --mathjax=vendor/tex-svg-full.js --css=book.css \
      --include-in-header=dictionary/book-head.html --metadata=lang:isv \
      --output=dictionary/book.html 04_NOETHER_INTERSLAVIC_DICTIONARY.tex
The shell line-continuation character may differ by operating system.
dictionary/INDEX.json is the machine-readable entry point and explains
identifier families, language roles, source hierarchy, and the file relationships.

Authorship and sources / Avtorstvo i izvory

The dictionary reconstruction and further bilingual explanations are
AI-created by OpenAI Codex — GPT-6 Astra, Ultra effort. Earlier methodological
exposition was AI-created by OpenAI Codex — GPT-5.6 Sol, Ultra effort.
No human translation, linguistic review, or community endorsement is claimed.
The inherited corpus's earlier model identity is not reliably established.

Emmy Noether and the named co-authors retain authorship of the mathematics.
The original corpus credits R. Brauer (Paper 32), R. Brauer and H. Hasse
(Paper 38), M. Deuring's account of Noether's lectures (work 44), and
H. Kapferer's Paper 45 with its appendix jointly written with E. Noether.
The dictionary cites the Interslavic Dictionary project, Jan van Steenbergen's
grammar and design criteria, and the human authors of comparative scholarship.
Full references and exact source identities accompany the entries and data.

MathJax 3.2.2: https://www.mathjax.org/ ; distributed under Apache License 2.0.
The unmodified combined tex-svg-full.js component and licence are included
under dictionary/vendor/. Their rights are not replaced by the edition notice.

The edition is offered free of charge for non-commercial, purely educational
purposes, on the publisher's presumption that rights holders would not object.
This is not established permission. Free access does not itself authorize a
derivative publication. Rights in originals and protected contributions remain
with their holders. Objections may be made at
https://github.com/KokunoYumeto/emmy-noether-isv/issues ; the publisher undertakes
to take down affected material upon a rights holder's request. No new
project-wide licence grant is made. The parallel Interslavic notice appears
in the dictionary and online reader.

The historical corpus DOI 10.5281/zenodo.21926382 identifies the corpus lineage,
not a DOI minted for this dictionary. Current publication is on GitHub.
